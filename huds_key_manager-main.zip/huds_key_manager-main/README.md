#DEPENDENCIES
#pip install pycryptodome


#The application runs on a configuration file, which is the sole controller,
#this file can be created manually, or the application can generate it automalically,
#with the necessary parameters, as shown below:

#################
#################

#This is the name of the encrypted database
#name_of_database             = cape_db.kdb
#the option below is meant to optionally specify the database path
#system_path                  =

#SPECIFY IF KEY/PASSPHRASE

#this option specifies whether the application should use an encryption key or a passphrase(password) 
#use_encryption_key           = True

#this is the size of the key if specified above is (use_encryption_key = True)
#master_key_size              = 10246

#this is the name of the master key if (use_encryption_key = True) 
#master_key_file_name         = cape_master-key.key

#this is the name of the master pass if (use_encryption_key = False) 
#master_pass_file_name        = cape_master-pass.ini

#################
#################

#NOTE: The directory .huds_mngnt_vault is a directory vault which contains
#      a log file, the default location of the encrypted database and the key/passphrase
#      hence, this dir can be optionally specified under (#system_path = )
#      (default naming is .huds_mngnt_vault)

#To automalically generate this file one can run the commands:

#STEP 1
#To start using this application, one must create a new *.ini file
#python -B _initialize.py -c .huds_mngnt_vault/cape.ini

#STEP 2
#ls .huds_mngnt_vault | grep -i cape.ini

#STEP 3
#python -B control_panel_.py -c .huds_mngnt_vault/cape.ini

#IMPORTANT (OPTIONAL)
#==========================================================================================
#The mapper.py file contains the naming convention of the fields that would be
#specified as inputs, hence the default fields are:

#organization
#repository
#username
#password
#database

#During the input process every other field can be left blank
#The files above can be changed accordingly, hence the required fields are:
#   username
#   password
#below is the mapping:
        # this file is editable
        # the originalfields are:
        # username='', password='', group='', title='', url=''
        # so for one to assign custom fields, one has to
        # define the custom fields in the key section of
        # the function mapperd
        
        #def mapperd (username='', password='', group='', title='', url=''):
        #   maps = {
        #       'organization'  : {'group': group},
        #       'repository'    : {'title': title},
        #       'username'      : {'username': username},
        #       'password'      : {'password': password},
        #       'database'      : {'url': url}
        #   }
        #   return maps
#===========================================================================================

#NOTE: from the above exercise, one can initialize multiple *.ini files which will come
#      with their respective, dbs and key/passphrases with the specified naming of that *.ini file
#      hence each and every *.ini files feeds to an encrypted database using a key/passphrase,
#      this means one can save credential data into diferent databases.
#      so to log into a a particular db one must do step three(3).
#python -B control_panel_.py -c .huds_mngnt_vault/cape.ini

#STEP 4
#after login, one can follow the prompt on the cli and perform the following actions
#input and view the respective data recorded.

#STEP 5
#to integrate this application to a script or some code, do the following:
#NOTE: the below code can be found in sample.py

#import the library
#from Enginehud.pam_soln_ import authpack

#invoke the class instance
#and specify the respective *.ini file
#auth   = authpack('.huds_mngnt_vault/GSOC.ini')

#The line below will spit out all the credentials in a form of a list with
#has json documents
#result = auth.dict_all_entries_from_db()

#we can use a loop to run through the list
#for i in result:
#    print i


