from Enginehud.pam_soln_ import authpack

auth = authpack()
auth.master_key()
auth.db_()
