from Enginehud.pam_soln_ import authpack

auth = authpack()
auth.input_ ()
